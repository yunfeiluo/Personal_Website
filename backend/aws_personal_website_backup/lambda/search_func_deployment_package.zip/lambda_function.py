import json
import boto3

import search_engine_lib.preprocess_query as pq

s3_obj = boto3.client('s3')

def lambda_handler(event, context):
    queries = event["query"]
    
    docs_list = pq.run(queries, s3_obj)
    
    # return response
    return {
        "headers":{
            "Access-Control-Allow-Origin": '*',
            "Access-Control-Allow-Credentials": True
        },
        "docs_list": docs_list
    }
