import json
import boto3

# fetch docs from database
db = boto3.resource('dynamodb')
table = db.Table('article')

s3 = boto3.client('s3')

# helper functions
def lambda_handler(event, context):
    bucket = event['Records'][0]['s3']['bucket']['name']
    file_name = event['Records'][0]['s3']['object']['key'] # it is the path in the bucket
    json_object = s3.get_object(Bucket=bucket, Key=file_name)
    json_file_reader = json_object['Body'].read()
    json_item = json.loads(json_file_reader)
    
    avai_id_obj = s3.get_object(Bucket="storage-2020", Key="avail_id.json")
    print(avai_id_obj)
    avail_id = json.loads(avai_id_obj['Body'].read())["avail_id"]
    
    json_item["id"] = int(avail_id)
    table.put_item(Item=json_item)
    
    avail_id += 1
    id_content = json.dumps({"avail_id": avail_id}).encode('utf-8')
    
    s3.put_object(Bucket="storage-2020", Key="avail_id.json", Body=id_content)
        
    # response
    return {
        'statusCode': 200
    }
