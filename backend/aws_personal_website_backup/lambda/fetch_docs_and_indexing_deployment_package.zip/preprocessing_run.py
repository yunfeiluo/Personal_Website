import json
from preprocess_and_indexing import preprocess, inverted_index

def preprocessing(list_, table, s3):
    # fetch stopwords
    stopwords = list()
    with open('stopwords.txt', 'r') as f:
        stopwords = f.read()
        stopwords = stopwords.split('\n')
        stopwords.pop()

    # fetch json file of the documents
    data = list_

    # tokenize, stopwords removal, stemming
    tokenize = preprocess(stopwords, data) # tokenize.text, map: ind -> [obj, [text]]
    tokenize.pre_process(table)
    # tokenize.stemming()
    tokenize.stopword_removel()
    inv_ind = inverted_index(tokenize.text).inv_ind # map: term -> map: doc_ind -> list of positions

    # write to s3 bucket
    bucket_name = "storage-2020"
    output_indexing = json.dumps(inv_ind).encode('utf-8')
    output_collection = json.dumps(tokenize.text).encode('utf-8')
    
    s3.put_object(Bucket=bucket_name, Key='indexing_.json', Body=output_indexing)
    s3.put_object(Bucket=bucket_name, Key='collection_.json', Body=output_collection)
    