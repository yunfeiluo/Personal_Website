import json
import boto3

import fetch_docs as fd
import preprocessing_run as pr

# fetch docs from database
db = boto3.resource('dynamodb')
table = db.Table('article')

s3 = boto3.client('s3')

def lambda_handler(event, context):
    # fetch documents
    list_ = fd.fetch_docs(table, s3)
    pr.preprocessing(list_, table, s3)
    
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
