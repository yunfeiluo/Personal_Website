import json

# helper functions
def dfs(doc, readed, table):
    if len(doc['docs']) == 0:
        return list()
    for i in range(len(doc['docs'])):
        item = table.get_item(Key={"id":doc["docs"][i]})
        if item.get("Item") == None:
            doc["docs"][i] = int(doc["docs"][i])
            continue
        readed[int(doc["docs"][i])] = True
        doc["docs"][i] = item["Item"]
        doc["docs"][i]['id'] = int(doc["docs"][i]['id'])
        dfs(doc["docs"][i], readed, table)
    

def fetch_docs(table, s3):
    list_ = {"documentations": list(), "blogs": list(), "reports": list()} # to be returned
    
    readed = dict()
    id_ = 1
    while True:
        if readed.get(id_) != None:
            id_ += 1
            continue
        item = table.get_item(Key={"id":id_})
        if item.get("Item") == None:
            break
        readed[id_] = True
        
        new_doc = item["Item"]
        dfs(new_doc, readed, table)
        
        new_doc['id'] = int(new_doc['id'])
        list_[new_doc["type"] + 's'].append(new_doc)
        
        id_ += 1
    
    #print(list_)
    
    # write to s3
    bucket_name = "storage-2020"
    output_list = json.dumps(list_).encode('utf-8')
    
    s3.put_object(Bucket=bucket_name, Key='list_.json', Body=output_list)
    return list_
